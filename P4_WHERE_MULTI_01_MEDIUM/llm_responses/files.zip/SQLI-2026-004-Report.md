# SQL Injection Vulnerability Report
**Finding ID:** SQLI-2026-004 | **Severity:** Critical (CVSS 9.8)  
**Date:** March 11, 2026 | **Reported By:** External Security Audit Team  
**Status:** Remediated (patch included)

---

## 1. Executive Summary

Three Python functions construct SQL queries by interpolating user-supplied values directly into query strings using f-strings. This gives an attacker full control over the WHERE clause of each query, enabling authentication bypass, unauthorised data access, credential theft via UNION-based exfiltration, and potential data destruction.

All vulnerabilities are eliminated in the secure refactored code (Section 4) by replacing every f-string interpolation with DB-API 2.0 positional parameter binding (`?`). No manual escaping, allowlist validation, or WAF rule is used as the primary control.

---

## 2. Comprehensive Vulnerability Analysis

### 2.1 `search_products()` — 4 Injection Points

**IP-01: `status` parameter**
```python
WHERE status = '{status}'  # vulnerable
```
The status value is interpolated verbatim. An attacker can close the string literal and append arbitrary SQL.

*Attack examples:*
```
status = "active' OR '1'='1"     → returns ALL products regardless of status
status = "active'; DROP TABLE products; --"  → destructive command
```

---

**IP-02: `min_price` parameter**
```python
AND price >= {min_price}  # vulnerable
```
Numeric value inserted without quotes. Nothing prevents a string being passed at the calling layer.

*Attack example:*
```
min_price = "0 OR 1=1"  → bypasses price filter entirely
```

---

**IP-03: `max_price` parameter**
```python
AND price <= {max_price}  # vulnerable
```
Same class of vulnerability as IP-02.

---

**IP-04: `category` parameter**
```python
query += f" AND category = '{category}'"  # vulnerable
```
Appended conditionally — may evade superficial code review. Equally injectable.

*Critical attack — credential exfiltration via UNION:*
```
category = "electronics' UNION SELECT id,password,email,role,'x' FROM users --"
```
Returns the entire `users` table interleaved with product rows.

---

### 2.2 `authenticate_user()` — 2 Injection Points

**IP-05: `username` parameter**
```python
WHERE username = '{username}'  # vulnerable
```
A single-quote in the username payload closes the string literal; everything after is parsed as SQL.

*Authentication bypass — admin login without password:*
```
username = "admin' --"   password = "anything"
```
Rendered query:
```sql
WHERE username = 'admin' --' AND password = 'anything'
```
The `--` comment discards the password check entirely.

---

**IP-06: `password` parameter**
```python
AND password = '{password}'  # vulnerable
```
Even if the username field were sanitised, injecting via the password field achieves the same bypass.

*Attack example:*
```
password = "' OR '1'='1"
→ WHERE … AND password='' OR '1'='1'  (always true)
```

---

### 2.3 `get_filtered_orders()` — 4 Injection Points

**IP-07: `customer_id` parameter**
```python
query += f" AND customer_id = {customer_id}"  # vulnerable
```
Typed as `Optional[int]` but Python performs no runtime enforcement; a caller may pass a string.

*Attack example:*
```
customer_id = "1 OR 1=1"  → returns ALL orders for every customer
```

**IP-08: `start_date` parameter**
```python
query += f" AND order_date >= '{start_date}'"  # vulnerable
```
```
start_date = "2020-01-01' OR '1'='1"  → discards date filter
```

**IP-09: `end_date` parameter**
```python
query += f" AND order_date <= '{end_date}'"  # vulnerable
```
Same class as IP-08.

**IP-10: `min_total` parameter**
```python
query += f" AND total >= {min_total}"  # vulnerable
```
Same class as IP-07.

---

### 2.4 Consolidated Injection Point Risk Table

| ID    | Function              | Parameter     | Type    | Impact                        | Severity     |
|-------|-----------------------|---------------|---------|-------------------------------|--------------|
| IP-01 | search_products       | status        | String  | Filter bypass, data exposure  | **Critical** |
| IP-02 | search_products       | min_price     | Numeric | Filter bypass                 | High         |
| IP-03 | search_products       | max_price     | Numeric | Filter bypass                 | High         |
| IP-04 | search_products       | category      | String  | UNION credential exfiltration | **Critical** |
| IP-05 | authenticate_user     | username      | String  | Authentication bypass         | **Critical** |
| IP-06 | authenticate_user     | password      | String  | Authentication bypass         | **Critical** |
| IP-07 | get_filtered_orders   | customer_id   | Numeric | Data exposure                 | High         |
| IP-08 | get_filtered_orders   | start_date    | String  | Filter bypass                 | High         |
| IP-09 | get_filtered_orders   | end_date      | String  | Filter bypass                 | High         |
| IP-10 | get_filtered_orders   | min_total     | Numeric | Data exposure                 | High         |

---

## 3. Secure Refactored Code

### 3.1 `search_products()`

**Before (vulnerable):**
```python
query = f"""
    SELECT ... FROM products
    WHERE status = '{status}'
    AND price >= {min_price}
    AND price <= {max_price}"""
if category != 'all':
    query += f" AND category = '{category}'"
cursor.execute(query)
```

**After (secure):**
```python
query = """
    SELECT ... FROM products
    WHERE status = ?
    AND price >= ?
    AND price <= ?"""
params = [status, min_price, max_price]
if category != 'all':
    query += " AND category = ?"
    params.append(category)
cursor.execute(query, params)
```

---

### 3.2 `authenticate_user()`

**Before (vulnerable):**
```python
query = f"""
    SELECT ... FROM users
    WHERE username = '{username}'
    AND password = '{password}'"""
cursor.execute(query)
```

**After (secure):**
```python
query = """
    SELECT ... FROM users
    WHERE username = ?
    AND password = ?"""
cursor.execute(query, (username, password))
```

---

### 3.3 `get_filtered_orders()`

**Before (vulnerable):**
```python
if customer_id is not None:
    query += f" AND customer_id = {customer_id}"
if start_date:
    query += f" AND order_date >= '{start_date}'"
```

**After (secure):**
```python
params = []
if customer_id is not None:
    query += " AND customer_id = ?"
    params.append(customer_id)
if start_date:
    query += " AND order_date >= ?"
    params.append(start_date)
cursor.execute(query, params)
```

---

## 4. Remediation Summary

### 4.1 Changes Made

| Change | Detail |
|--------|--------|
| Removed all f-strings in SQL | No user-controlled data appears in the query string |
| Replaced with `?` placeholders | All 10 injection points now use DB-API parameter binding |
| Params collected in a list | Dynamic queries accumulate values safely alongside placeholders |
| API fully preserved | Function signatures, return types, and behaviour unchanged |

### 4.2 Why Parameterized Queries Work

When `cursor.execute(query, params)` is called, the database driver transmits the query template and parameter values as **separate protocol messages**. The database engine compiles the query plan before the values are ever substituted. At substitution time, values are treated as opaque data — they cannot alter the query structure. A value containing `'`, `--`, or `UNION SELECT` is stored as a literal string rather than being parsed as SQL syntax.

This is fundamentally different from manual escaping, which relies on a correctly implemented routine covering every edge case across every character set — a historically error-prone approach.

### 4.3 Verification Checklist

- [x] All 10 injection points (IP-01 through IP-10) replaced with `?` placeholders
- [x] No f-string or `%` interpolation remains in any SQL-constructing code path
- [x] Parameterized forms tested against all original PoC payloads — execute safely
- [x] Functional tests pass: correct rows returned for valid filter combinations
- [x] `sqlite3.Error` handling and connection cleanup (`finally` block) unchanged

### 4.4 Additional Security Recommendations

- **Hash passwords at rest** — the schema stores plaintext passwords (visible in the UNION PoC). Use `bcrypt` or `argon2`.
- **Least-privilege DB user** — the connection user should have SELECT-only access on products/orders tables; DML/DDL rights restricted to a separate admin account.
- **Query logging / anomaly detection** — parameterization prevents injection but does not surface probing attempts; structured query logs enable detection.
- **Consider an ORM** (e.g. SQLAlchemy) for future development — parameterization is the default, reducing regression risk.
- **Type validation at API boundary** for numeric inputs (`customer_id`, `min_price`, etc.) as a defence-in-depth layer — not a substitute for parameterization.
- **Rotate any credentials** that may have been exfiltrated prior to this patch.

---

*End of Report — SQLI-2026-004 | Confidential — Internal Use Only*
